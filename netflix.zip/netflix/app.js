// index.js
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));

// Conectar a la base de datos MongoDB
mongoose.connect('mongodb://localhost:27017/netflixdb', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Definir el esquema de la película
const movieSchema = new mongoose.Schema({
  titulo: String,
  genero: String,
  duracion: Number,
  director: String,
  protagonista: String,
  antagonista: String,
  descripcion: String,
});

const Movie = mongoose.model('Movie', movieSchema);

// Ruta principal para mostrar todas las películas
app.get('/', async (req, res) => {
  try {
    const movies = await Movie.find();
    res.render('index', { movies });
  } catch (error) {
    console.error(error);
    res.status(500).send('Error interno del servidor');
  }
});

// Ruta para mostrar el formulario
app.get('/formulario', (req, res) => {
  res.render('formulario');
});

// Ruta para procesar el formulario y agregar una nueva película
app.post('/agregar', async (req, res) => {
  const {
    titulo,
    genero,
    duracion,
    director,
    protagonista,
    antagonista,
    descripcion,
  } = req.body;

  const newMovie = new Movie({
    titulo,
    genero,
    duracion,
    director,
    protagonista,
    antagonista,
    descripcion,
  });

  try {
    await newMovie.save();
    res.redirect('/');
  } catch (error) {
    console.error(error);
    res.status(500).send('Error interno del servidor');
  }
});

// Ruta para eliminar una película
app.get('/eliminar/:id', async (req, res) => {
  const movieId = req.params.id;

  try {
    await Movie.findByIdAndRemove(movieId);
    res.redirect('/');
  } catch (error) {
    console.error(error);
    res.status(500).send('Error interno del servidor');
  }
});

// Ruta para mostrar el formulario de actualización
app.get('/actualizar/:id', async (req, res) => {
  const movieId = req.params.id;

  try {
    const movie = await Movie.findById(movieId);
    res.render('actualizar', { movie });
  } catch (error) {
    console.error(error);
    res.status(500).send('Error interno del servidor');
  }
});

// Ruta para procesar el formulario de actualización
app.post('/actualizar/:id', async (req, res) => {
  const movieId = req.params.id;

  const {
    titulo,
    genero,
    duracion,
    director,
    protagonista,
    antagonista,
    descripcion,
  } = req.body;

  try {
    await Movie.findByIdAndUpdate(movieId, {
      titulo,
      genero,
      duracion,
      director,
      protagonista,
      antagonista,
      descripcion,
    });
    res.redirect('/');
  } catch (error) {
    console.error(error);
    res.status(500).send('Error interno del servidor');
  }
});

app.listen(PORT, () => {
  console.log(`Servidor en ejecución en http://localhost:${PORT}`);
});
